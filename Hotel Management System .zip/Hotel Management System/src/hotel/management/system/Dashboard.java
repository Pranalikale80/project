package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Dashboard extends JFrame implements ActionListener {
    
    Dashboard(){
        setBounds(0,0,1500,1000);
        setUndecorated(true);
        setLayout(null);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550, 1000, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0,1366,768);
        add(image);
                      
        JMenuBar mb = new JMenuBar();
        mb.setBounds(60,0,2200,50);
        //mb.setBackground(Color.red);
        image.add(mb);
        
        ImageIcon logoIcon = new ImageIcon(ClassLoader.getSystemResource("icons/bglogo.jpg"));
        Image logoImage = logoIcon.getImage().getScaledInstance(60, 50, Image.SCALE_DEFAULT);
        ImageIcon scaledLogoIcon = new ImageIcon(logoImage);
        JLabel logoLabel = new JLabel(scaledLogoIcon);
        logoLabel.setBounds(0, 0, 60, 50); 
        image.add(logoLabel); // Adding logo at the start
        
        JMenu hotel = new JMenu("HOTEL MANAGEMENT");
        hotel.setForeground(Color.RED);
        mb.add(hotel);
        
        JMenuItem reception = new JMenuItem("RECEPTION");
        reception.addActionListener(this);
        hotel.add(reception);
        
        JMenu admin = new JMenu("ADMIN");
        admin.setForeground(Color.BLUE);
        mb.add(admin);
                        
        JMenuItem addemployee = new JMenuItem("ADD EMPLOYEE");
        addemployee.addActionListener(this);
        admin.add(addemployee);
        
        JMenuItem addrooms = new JMenuItem("ADD ROOMS");
        addrooms.addActionListener(this);
        admin.add(addrooms);
                      
        JMenuItem adddrives = new JMenuItem("ADD DRIVERS");
        adddrives.addActionListener(this);
        admin.add(adddrives);
        
                
//        JMenu Report = new JMenu("REPORT");
//        Report.setForeground(Color.BLACK);
//        Report.addActionListener(this);
//        //mb.add(Report.createHorizontalGlue()); // Adds flexible space to push exit icon to the right
//        mb.add(Report);
//        

        
        
        
             
         // Adding exit menu item at the end
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(e -> System.exit(0));
        ImageIcon exitIcon = new ImageIcon(ClassLoader.getSystemResource("icons/exit.png"));
        exitMenuItem.setIcon(exitIcon);
        mb.add(Box.createHorizontalGlue()); // Adds flexible space to push exit icon to the right
        mb.add(exitMenuItem); // Adding exit icon at the end
        
        // Adding REPORT menu to the end
       
        
        JMenu report = new JMenu("REPORT");
        report.setForeground(Color.black);
        mb.add(report,mb.getComponentCount() - 1);
        
        JMenuItem reportItem = new JMenuItem("ALL REPORTS");
        reportItem.addActionListener(this);
        report.add(reportItem);
        
        //,mb.getComponentCount() - 1
        
        
//        JMenuItem customer = new JMenuItem("CUSTOMER DETAILS");
//        customer.addActionListener(this);
//        report.add(customer);
//                      
//        JMenuItem employee = new JMenuItem("EMPLOYEE DETAILS");
//        employee.addActionListener(this);
//        report.add(employee);
        
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae) {
        if(ae.getActionCommand().equals("ADD EMPLOYEE")){
        new AddEmployee();
        } else if(ae.getActionCommand().equals("ADD ROOMS")) {
        new AddRooms();
        } else if(ae.getActionCommand().equals("ADD DRIVERS")){
        new AddDriver();
        } else if(ae.getActionCommand().equals("RECEPTION")){
        new Reception();
        } 
        else if(ae.getActionCommand().equals("ALL REPORTS")){
        new Report();
        }
    }
    
    
    
    public static void main(String[] args){
        new Dashboard();
    }
}
