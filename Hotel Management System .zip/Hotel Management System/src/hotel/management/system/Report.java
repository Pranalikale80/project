package hotel.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;


public class Report extends JFrame implements ActionListener {

    JButton customer, Employee, room, drivers, department, cancel;
    Report() {

        setSize(500, 450);
        setLocation(800, 100);
        setLayout(null);
        setUndecorated(true);
        getContentPane().setBackground(Color.lightGray);
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/bg report.jpg"));
        Image i2 = i1.getImage().getScaledInstance( 500,450, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0,500,450);
        add(image);
           

//        exits = new JButton();
//        exits.addActionListener(e -> System.exit(0));
//        ImageIcon exitIcon = new ImageIcon(ClassLoader.getSystemResource("icons/exits.png"));
//        //exit.setBounds(50, 30, 45, 30);
//        exits.setIcon(exitIcon);
//        
//        // Calculate the x position for the exit button
//        int exitX = getWidth() - 60; // Assuming button width is 100
//        
//        exits.setBounds(exitX, 20, 35, 30);
//        add(exits);
        
        JLabel heading = new JLabel("REPORTS");
        heading.setFont(new Font("Tahoma",Font.BOLD,18));
        heading.setBounds(200,20,200,20);
        image.add(heading);

        customer = new JButton("Customer Details");
        customer.setForeground(Color.black);
        customer.setBounds(70, 90, 150, 30); 
        customer.addActionListener(this);
        add(customer);
        
        Employee = new JButton(" Employees Details");
        Employee.setForeground(Color.black);
        Employee.setBounds(270, 90, 150, 30); 
        Employee.addActionListener(this);
        add(Employee); 
        
        room = new JButton(" Room Details");
        room.setForeground(Color.black);
        room.setBounds(70, 190, 150, 30); 
        room.addActionListener(this);
        add(room); 

        drivers = new JButton(" Drivers Details");
        drivers.setForeground(Color.black);
        drivers.setBounds(270, 190, 150, 30); 
        drivers.addActionListener(this);
        add(drivers); 

        department = new JButton(" Department Details");
        department.setForeground(Color.black);
        department.setBounds(170, 290, 150, 30); 
        department.addActionListener(this);
        add(department);
        
        cancel = new JButton("Cancel");
        cancel.setForeground(Color.WHITE);
        cancel.setBackground(Color.BLACK);
        cancel.setBounds(170,370,150,30);
        cancel.addActionListener(this);
        add(cancel);
        
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == customer) {
            openPDF("C:/Users/DELL/Documents/Report/customerReport.pdf");
        } else if (ae.getSource() == Employee) {
            openPDF("C:/Users/DELL/Documents/Report/employeeReport.pdf");
        } 
        else if (ae.getSource() == room) {
            openPDF("C:/Users/DELL/Documents/Report/roomReport.pdf");
        } 
        else if (ae.getSource() == drivers) {
            openPDF("C:/Users/DELL/Documents/Report/driversReport.pdf");
        } 
        else if (ae.getSource() == department) {
            openPDF("C:/Users/DELL/Documents/Report/departmentReport.pdf");
        }
        
        // back to dashboard page
        setVisible(false);
        //new Dashboard();
    }

    private void openPDF(String filePath) {
        try {
            File file = new File(filePath);
            if (file.exists()) {
                Desktop.getDesktop().open(file);
            } else {
                System.out.println("File not found: " + filePath);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Report());
    }  
}