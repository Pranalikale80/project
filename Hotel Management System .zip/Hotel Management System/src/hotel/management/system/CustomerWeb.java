// new page

package hotel.management.system;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class CustomerWeb extends JFrame implements ActionListener {
    
    CustomerWeb(){
        setBounds(0,70,1370,700);
        getContentPane().setBackground(Color.WHITE);
        setUndecorated(true);
        setLayout(null);
        
        
        
        setVisible(true); 
    }
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
    }
    public static void main(String[] args) {
       new CustomerWeb();
   }
}
