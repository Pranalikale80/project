package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;


public class CustomerInfo extends JFrame implements ActionListener{
    JTable table;
    JButton back;
    
    CustomerInfo(){
        
        getContentPane().setBackground(Color.white);
        setUndecorated(true);
        setLayout(null);
              
        JLabel l1=new JLabel("Name");
        l1.setBounds(20, 10, 100, 20);
        add(l1);
                        
        JLabel l2=new JLabel("Contact");
        l2.setBounds(130, 10, 100, 20);
        add(l2);
        
        JLabel l3=new JLabel("Document Type");
        l3.setBounds(250, 10, 100, 20);
        add(l3);
        
        JLabel l4=new JLabel("Number");
        l4.setBounds(370, 10, 100, 20);
        add(l4);
        
        JLabel l5=new JLabel("Gender");
        l5.setBounds(490, 10, 100, 20);
        add(l5);
        
        JLabel l6=new JLabel("Country");
        l6.setBounds(610, 10, 100, 20);
        add(l6);
        
        JLabel l7=new JLabel("Room Number");
        l7.setBounds(720, 10, 100, 20);
        add(l7);
        
        JLabel l8=new JLabel("Checkin time");
        l8.setBounds(840, 10, 100, 20);
        add(l8);
        
        JLabel l9 =new JLabel("Deposit ");
        l9.setBounds(970, 10, 100, 20);
        add(l9);
        
        JLabel l10 =new JLabel("Pending ");
        l10.setBounds(1090, 10, 100, 20);
        add(l10);
        
        table = new JTable();
        table.setBounds(1, 40, 1180, 400);
        add(table);
        
        try{
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("Select * from Customer");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e){
            e.printStackTrace();
        }    
            
        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setBounds(490,500,120,30); //....
        back.addActionListener(this);
        add(back);
        
        setBounds(90,100,1180,600);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Reception();
    }
    
    public static void main(String[] args){
        new CustomerInfo();
    }
}
