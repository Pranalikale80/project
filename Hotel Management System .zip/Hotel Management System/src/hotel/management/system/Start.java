package hotel.management.system;

import java.awt.*;
import javax.swing.*;

public class Start extends JFrame {

    JProgressBar progressBar;
    JLabel statusLabel;

    Start() {
        setUndecorated(true);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/start.jpg"));
        Image i2 = i1.getImage().getScaledInstance(610, 360, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(20, 20, 610, 360);
        add(image);

        // Creating and configuring the progress bar
        progressBar = new JProgressBar();
        progressBar.setBounds(20, 430, 600, 20); // Adjust the position and size as needed
        progressBar.setStringPainted(true); // Display percentage text on the progress bar
        progressBar.setForeground(new Color(210, 105, 30)); // Light brown color
        progressBar.setBackground(new Color(255, 228, 181)); // Background color
        add(progressBar);

        // Label to show status
        statusLabel = new JLabel();
        statusLabel.setBounds(150, 400, 600, 20); // Adjust position as needed
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        statusLabel.setForeground(Color.BLACK);
        add(statusLabel);

        setBounds(350, 150, 652, 460);
        setVisible(true);

        // Simulating progress (replace this with your actual loading process)
        simulateProgress();
    }

    // Method to simulate progress (Replace this with your actual loading process)
    private void simulateProgress() {
        int progress = 0;
        while (progress <= 100) {
            try {
                Thread.sleep(100); // Simulating some task being done
                progressBar.setValue(progress);
                updateStatusLabel(progress);
                progress++;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        openLoginPage(); // Open the login page when loading is complete
        dispose(); // Close the window when loading is complete
    }

    // Method to update status label based on progress
    private void updateStatusLabel(int progress) {
        if (progress == 10)
            statusLabel.setText("Loading Connecting...");
        else if (progress == 30)
            statusLabel.setText("Loading Connection Database...");
        else if (progress == 70)
            statusLabel.setText("Launch Application...");
        else if (progress == 90)
            statusLabel.setText("Almost Done...");
    }

    // Method to open the login page
    private void openLoginPage() {
        // Code to create and display the login page
        new Login().setVisible(true);
    }

    public static void main(String[] args) {
        new Start();
    }
}
