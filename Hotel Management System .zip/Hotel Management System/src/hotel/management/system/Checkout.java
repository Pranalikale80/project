package hotel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Date;

public class Checkout extends JFrame implements ActionListener {

    Choice ccustomer;
    JTextField tfroom, tfcheckin;
    JLabel lblroomnumber, lblcheckintime, lblcheckouttime;
    JButton check, Checkout, back;

    Checkout() {
        getContentPane().setBackground(Color.white);
        setUndecorated(true);
        setLayout(null);

        JLabel text = new JLabel("Checkout");
        text.setBounds(100, 20, 100, 30);
        text.setForeground(Color.blue);
        text.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(text);

        JLabel lblname = new JLabel("Name");
        lblname.setBounds(30, 80, 100, 30);
        add(lblname);

        ccustomer = new Choice();
        ccustomer.setBounds(150, 80, 150, 25);
        add(ccustomer);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/tick.png"));
        Image i2 = i1.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel tick = new JLabel(i3);
        tick.setBounds(310, 80, 20, 20);
        add(tick);

        JLabel lblroom = new JLabel("Room Number");
        lblroom.setBounds(30, 130, 100, 30);
        add(lblroom);

        tfroom = new JTextField(); // Initializing text field
        tfroom.setBounds(150, 130, 100, 30);
        tfroom.setBorder(null); // Disabling border
        add(tfroom);

        JLabel lblcheckin = new JLabel("Checkin Time");
        lblcheckin.setBounds(30, 180, 100, 30);
        add(lblcheckin);

        tfcheckin = new JTextField(); // Initializing text field
        tfcheckin.setBounds(150, 180, 200, 30);
        tfcheckin.setBorder(null); // Disabling border
        add(tfcheckin);

        JLabel lblcheckout = new JLabel("Checkout Time");
        lblcheckout.setBounds(30, 230, 100, 30);
        add(lblcheckout);

        Date date = new Date();
        lblcheckouttime = new JLabel("" + date);
        lblcheckouttime.setBounds(150, 230, 200, 30);
        add(lblcheckouttime);

        // check 
        check = new JButton("Check");
        check.setBackground(Color.BLACK);
        check.setForeground(Color.WHITE);
        check.setBounds(30, 320, 100, 30);
        check.addActionListener(this);
        add(check);

        Checkout = new JButton("Checkout");
        Checkout.setBackground(Color.black);
        Checkout.setForeground(Color.white);
        Checkout.setBounds(170, 320, 120, 30);
        Checkout.addActionListener(this);
        add(Checkout);

        back = new JButton("Back");
        back.setBackground(Color.black);
        back.setForeground(Color.white);
        back.setBounds(330, 320, 120, 30);
        back.addActionListener(this);
        add(back);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from customer"); // where
            while (rs.next()) {
                ccustomer.add(rs.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/sixth.jpg"));
        Image i5 = i4.getImage().getScaledInstance(400, 250, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel image = new JLabel(i6);
        image.setBounds(350, 60, 400, 250);
        add(image);

        setBounds(300, 200, 800, 400);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == check) {
            String name = ccustomer.getSelectedItem();
            String query = "select * from customer where name = '" + name + "'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                if (rs.next()) {
                    tfroom.setText(rs.getString("room"));
                    tfcheckin.setText(rs.getString("checkintime"));
                } else {
                    JOptionPane.showMessageDialog(null, "No record found for the selected customer.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == Checkout) {
            String name = ccustomer.getSelectedItem();
            String query1 = "delete from customer where name = '" + name + "'";
            String query2 = "update room set availability = 'Available' where roomnumber ='" + tfroom.getText() + "'";
            try {
                Conn c = new Conn();
                c.s.executeUpdate(query1);
                c.s.executeUpdate(query2);
                JOptionPane.showMessageDialog(null, "Checkout done");
                setVisible(false);
                new Reception();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
            new Reception();
        }
    }

    public static void main(String[] args) {
        new Checkout();
    }
}
